<!DOCTYPE html>
	<html lang="en-US">
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Log In &lsaquo; SG Pro Growth &#8212; WordPress</title>
	        <style type="text/css">
                            body.login div#login h1 a {
                    background-image: url(https://sharvaconsulting.com/wp-content/uploads/2025/08/1000325607.jpeg);
                }
                            .bp_social_connect{text-align:center;}
            .bp_social_connect>a{display:inline-block;float:none !important;text-decoration:none;}
            .bp_social_connect>a:before{content:'' !important;}
            .login h1 a{
                width:160px;
                background-size:100%;
            }
            html,body.login {
                background: #313b3d;
                }
            body:before{
                content:'';
                background:rgba(0,0,0,0.1);
                width:100%;
                height:10px;
                position:absolute;
                top:0;
                left:0;
            }    
            body.login form#loginform label{
                color: #fff;
                font-size:11px;
                text-transform: uppercase;
                font-weight:600;
                opacity: 0.8;
            }
            body.login input[type=checkbox]:checked:before{color: #fff;}
            body.login.wp-core-ui .button-primary{background:#0B2860;border:none;box-shadow:none;text-shadow:none;color:#FFFFFF;}
            body.login form#loginform {
                background:#fff;
                box-shadow:none;
                border-radius:2px;
                margin:0;
            }    
            body.login form#loginform label{color:#333;}
            body.login form#loginform .input,
            body.login form#loginform input[type=text], 
            body.login form#loginform input[type=checkbox]{
                background: #313b3d;
                border-color: rgba(255,255,255,0.1);
                border-radius: 2px;
                color:#fff;
            }
            body.login #nav a, body.login #backtoblog a{
                color: #fff;
                text-transform: uppercase;
                font-size: 11px;
                opacity: 0.8;
            }
            body.login #nav a:hover, body.login #backtoblog a:hover{color:#0B2860}
            div.error,body.login #login_error{border-radius:2px;}
                    </style>
        <meta name='robots' content='max-image-preview:large, noindex, noarchive' />
<script type="text/javascript" src="https://sharvaconsulting.com/wp-content/plugins/vibebp/includes/../assets/js/iziToast.min.js?ver=1.9.9.8" id="iziToast-js"></script>
<link rel='stylesheet' id='iziToast-css' href='https://sharvaconsulting.com/wp-content/plugins/vibebp/includes/../assets/css/iziToast.min.css?ver=1.9.9.8' type='text/css' media='all' />
<link rel='stylesheet' id='formidable-css' href='https://sharvaconsulting.com/wp-content/plugins/formidable/css/formidableforms.css?ver=4141055' type='text/css' media='all' />
<link rel='stylesheet' id='dashicons-css' href='https://sharvaconsulting.com/wp-includes/css/dashicons.min.css?ver=6.8.5' type='text/css' media='all' />
<link rel='stylesheet' id='buttons-css' href='https://sharvaconsulting.com/wp-includes/css/buttons.min.css?ver=6.8.5' type='text/css' media='all' />
<link rel='stylesheet' id='forms-css' href='https://sharvaconsulting.com/wp-admin/css/forms.min.css?ver=6.8.5' type='text/css' media='all' />
<link rel='stylesheet' id='l10n-css' href='https://sharvaconsulting.com/wp-admin/css/l10n.min.css?ver=6.8.5' type='text/css' media='all' />
<link rel='stylesheet' id='login-css' href='https://sharvaconsulting.com/wp-admin/css/login.min.css?ver=6.8.5' type='text/css' media='all' />
	<meta name='referrer' content='strict-origin-when-cross-origin' />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<link rel="icon" href="https://sharvaconsulting.com/wp-content/uploads/2025/08/cropped-1000325607-1-32x32.jpeg" sizes="32x32" />
<link rel="icon" href="https://sharvaconsulting.com/wp-content/uploads/2025/08/cropped-1000325607-1-192x192.jpeg" sizes="192x192" />
<link rel="apple-touch-icon" href="https://sharvaconsulting.com/wp-content/uploads/2025/08/cropped-1000325607-1-180x180.jpeg" />
<meta name="msapplication-TileImage" content="https://sharvaconsulting.com/wp-content/uploads/2025/08/cropped-1000325607-1-270x270.jpeg" />
	</head>
	<body class="login no-js login-action-login wp-core-ui  locale-en-us">
	<script type="text/javascript">
/* <![CDATA[ */
document.body.className = document.body.className.replace('no-js','js');
/* ]]> */
</script>

				<h1 class="screen-reader-text">Log In</h1>
			<div id="login">
		<h1 role="presentation" class="wp-login-logo"><a href="https://sharvaconsulting.com/">SG Pro Growth</a></h1>
	
		<form name="loginform" id="loginform" action="https://sharvaconsulting.com/wp-login.php" method="post">
			<p>
				<label for="user_login">Username or Email Address</label>
				<input type="text" name="log" id="user_login" class="input" value="" size="20" autocapitalize="off" autocomplete="username" required="required" />
			</p>

			<div class="user-pass-wrap">
				<label for="user_pass">Password</label>
				<div class="wp-pwd">
					<input type="password" name="pwd" id="user_pass" class="input password-input" value="" size="20" autocomplete="current-password" spellcheck="false" required="required" />
					<button type="button" class="button button-secondary wp-hide-pw hide-if-no-js" data-toggle="0" aria-label="Show password">
						<span class="dashicons dashicons-visibility" aria-hidden="true"></span>
					</button>
				</div>
			</div>
						<p class="forgetmenot"><input name="rememberme" type="checkbox" id="rememberme" value="forever"  /> <label for="rememberme">Remember Me</label></p>
			<p class="submit">
				<input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" value="Log In" />
									<input type="hidden" name="redirect_to" value="https://sharvaconsulting.com/wp-admin/" />
									<input type="hidden" name="testcookie" value="1" />
			</p>
		</form>

					<p id="nav">
				<a class="wp-login-register" href="https://sharvaconsulting.com/register/">Register</a> | <a class="wp-login-lost-password" href="https://sharvaconsulting.com/wp-login.php?action=lostpassword">Lost your password?</a>			</p>
			<script type="text/javascript">
/* <![CDATA[ */
function wp_attempt_focus() {setTimeout( function() {try {d = document.getElementById( "user_login" );d.focus(); d.select();} catch( er ) {}}, 200);}
wp_attempt_focus();
if ( typeof wpOnload === 'function' ) { wpOnload() }
/* ]]> */
</script>
		<p id="backtoblog">
			<a href="https://sharvaconsulting.com/">&larr; Go to SG Pro Growth</a>		</p>
		<div class="privacy-policy-page-link"><a class="privacy-policy-link" href="https://sharvaconsulting.com/privacy-policy/" rel="privacy-policy">Privacy Policy</a></div>	</div>
		
	<script type="text/javascript" src="https://sharvaconsulting.com/wp-includes/js/clipboard.min.js?ver=2.0.11" id="clipboard-js"></script>
<script type="text/javascript" src="https://sharvaconsulting.com/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script type="text/javascript" src="https://sharvaconsulting.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
<script type="text/javascript" id="zxcvbn-async-js-extra">
/* <![CDATA[ */
var _zxcvbnSettings = {"src":"https:\/\/sharvaconsulting.com\/wp-includes\/js\/zxcvbn.min.js"};
/* ]]> */
</script>
<script type="text/javascript" src="https://sharvaconsulting.com/wp-includes/js/zxcvbn-async.min.js?ver=1.0" id="zxcvbn-async-js"></script>
<script type="text/javascript" src="https://sharvaconsulting.com/wp-includes/js/dist/hooks.min.js?ver=4d63a3d491d11ffd8ac6" id="wp-hooks-js"></script>
<script type="text/javascript" src="https://sharvaconsulting.com/wp-includes/js/dist/i18n.min.js?ver=5e580eb46a90c2b997e6" id="wp-i18n-js"></script>
<script type="text/javascript" id="wp-i18n-js-after">
/* <![CDATA[ */
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
/* ]]> */
</script>
<script type="text/javascript" id="password-strength-meter-js-extra">
/* <![CDATA[ */
var pwsL10n = {"unknown":"Password strength unknown","short":"Very weak","bad":"Weak","good":"Medium","strong":"Strong","mismatch":"Mismatch"};
/* ]]> */
</script>
<script type="text/javascript" src="https://sharvaconsulting.com/wp-admin/js/password-strength-meter.min.js?ver=6.8.5" id="password-strength-meter-js"></script>
<script type="text/javascript" src="https://sharvaconsulting.com/wp-includes/js/underscore.min.js?ver=1.13.7" id="underscore-js"></script>
<script type="text/javascript" id="wp-util-js-extra">
/* <![CDATA[ */
var _wpUtilSettings = {"ajax":{"url":"\/wp-admin\/admin-ajax.php"}};
/* ]]> */
</script>
<script type="text/javascript" src="https://sharvaconsulting.com/wp-includes/js/wp-util.min.js?ver=6.8.5" id="wp-util-js"></script>
<script type="text/javascript" src="https://sharvaconsulting.com/wp-includes/js/dist/dom-ready.min.js?ver=f77871ff7694fffea381" id="wp-dom-ready-js"></script>
<script type="text/javascript" src="https://sharvaconsulting.com/wp-includes/js/dist/a11y.min.js?ver=3156534cc54473497e14" id="wp-a11y-js"></script>
<script type="text/javascript" id="user-profile-js-extra">
/* <![CDATA[ */
var userProfileL10n = {"user_id":"0","nonce":"334e7ae2bb"};
/* ]]> */
</script>
<script type="text/javascript" src="https://sharvaconsulting.com/wp-admin/js/user-profile.min.js?ver=6.8.5" id="user-profile-js"></script>
	</body>
	</html>
	